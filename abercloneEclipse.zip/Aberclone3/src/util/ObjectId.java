package util;

public enum ObjectId {
	
	Flower(), Tree(), OtherPlayer();
	
}
